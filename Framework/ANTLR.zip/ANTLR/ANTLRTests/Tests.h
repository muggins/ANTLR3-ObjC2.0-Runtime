//
//  Tests.h
//  Tests
//
//  Created by Alan Condit on 4/7/11.
//  Copyright 2011 Alan's MachineWorks. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Tests : SenTestCase {
@private
    
}

@end
